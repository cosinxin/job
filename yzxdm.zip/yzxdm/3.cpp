#include <iostream>
#include <vector>
#include <random>
#include <chrono>
#include <algorithm>
#include <sstream>
#include <stdexcept>
#include <cstdint>

using namespace std;

// ===================== 全局配置 =====================
namespace Config {
    int MOD_PRIME = 10007;
    bool isPrime(int x) {
        if (x < 2) return false;
        if (x % 2 == 0) return x == 2;
        for (int d = 3; 1LL * d * d <= x; d += 2)
            if (x % d == 0) return false;
        return true;
    }
}

// ===================== 有限域运算 =====================
class FiniteField {
public:
    static inline int mod(long long x) {
        x %= Config::MOD_PRIME;
        return x < 0 ? x + Config::MOD_PRIME : (int)x;
    }
    static inline int add(int a, int b) { return mod((long long)a + b); }
    static inline int sub(int a, int b) { return mod((long long)a - b); }
    static inline int mul(int a, int b) {
        __int128 t = (__int128)a * (__int128)b;
        return mod((long long)(t % Config::MOD_PRIME));
    }
    static int pow(int a, long long e) {
        long long r = 1, b = mod(a);
        while (e) {
            if (e & 1) r = (r * b) % Config::MOD_PRIME;
            b = (b * b) % Config::MOD_PRIME;
            e >>= 1;
        }
        return (int)r;
    }
    static int inv(int a) {
        if (a == 0) throw runtime_error("Inverse does not exist");
        return pow(a, Config::MOD_PRIME - 2);
    }
};

// ===================== 大整数类（仅支持必要操作） =====================
class BigUInt {
    vector<uint32_t> data;
    void normalize() {
        while (!data.empty() && data.back() == 0) data.pop_back();
    }
public:
    BigUInt(uint64_t x = 0) {
        if (x) {
            data.push_back((uint32_t)(x & 0xffffffff));
            if (x >> 32) data.push_back((uint32_t)(x >> 32));
        }
    }
    bool zero() const { return data.empty(); }
    bool odd() const { return !zero() && (data[0] & 1); }
    void multiply(uint32_t m) {
        if (zero() || m == 0) { data.clear(); return; }
        uint64_t carry = 0;
        for (size_t i = 0; i < data.size(); ++i) {
            uint64_t cur = (uint64_t)data[i] * m + carry;
            data[i] = (uint32_t)(cur & 0xffffffff);
            carry = cur >> 32;
        }
        if (carry) data.push_back((uint32_t)carry);
    }
    void decrement() {
        if (zero()) throw runtime_error("BigUInt is zero");
        for (size_t i = 0; i < data.size(); ++i) {
            if (data[i] > 0) { data[i]--; break; }
            data[i] = 0xffffffff;
        }
        normalize();
    }
    void shiftRight() {
        uint32_t carry = 0;
        for (size_t i = data.size(); i-- > 0;) {
            uint32_t new_carry = (data[i] & 1) ? 0x80000000 : 0;
            data[i] = (data[i] >> 1) | carry;
            carry = new_carry;
        }
        normalize();
    }
};

// ===================== 多项式类 =====================
class Polynomial {
    vector<int> coeff; // coeff[i] = x^i 的系数
    void trim() {
        while (!coeff.empty() && coeff.back() == 0) coeff.pop_back();
    }
public:
    Polynomial() = default;
    explicit Polynomial(int c) { if (c) coeff = {FiniteField::mod(c)}; }
    static Polynomial monomial(int degree) {
        Polynomial p;
        p.coeff.assign(degree + 1, 0);
        p.coeff[degree] = 1;
        return p;
    }
    static Polynomial x() { return monomial(1); }
    bool isZero() const { return coeff.empty(); }
    bool isOne() const { return coeff.size() == 1 && coeff[0] == 1; }
    int degree() const { return (int)coeff.size() - 1; }
    int leading() const { return isZero() ? 0 : coeff.back(); }
    string toString() const {
        if (isZero()) return "0";
        ostringstream oss;
        bool first = true;
        for (int i = degree(); i >= 0; --i) {
            int c = coeff[i];
            if (!c) continue;
            if (!first) oss << " + ";
            first = false;
            if (i == 0) oss << c;
            else if (i == 1) oss << (c == 1 ? "x" : to_string(c) + "*x");
            else oss << (c == 1 ? "x^" + to_string(i) : to_string(c) + "*x^" + to_string(i));
        }
        return oss.str();
    }
    const vector<int>& raw() const { return coeff; }
    
    Polynomial operator+(const Polynomial& other) const {
        int n = max(degree(), other.degree()) + 1;
        Polynomial res;
        res.coeff.assign(n, 0);
        for (int i = 0; i < n; ++i) {
            int v = 0;
            if (i < (int)coeff.size()) v = FiniteField::add(v, coeff[i]);
            if (i < (int)other.coeff.size()) v = FiniteField::add(v, other.coeff[i]);
            res.coeff[i] = v;
        }
        res.trim();
        return res;
    }
    Polynomial operator-(const Polynomial& other) const {
        int n = max(degree(), other.degree()) + 1;
        Polynomial res;
        res.coeff.assign(n, 0);
        for (int i = 0; i < n; ++i) {
            int v = 0;
            if (i < (int)coeff.size()) v = FiniteField::add(v, coeff[i]);
            if (i < (int)other.coeff.size()) v = FiniteField::sub(v, other.coeff[i]);
            res.coeff[i] = v;
        }
        res.trim();
        return res;
    }
    Polynomial operator*(const Polynomial& other) const {
        if (isZero() || other.isZero()) return Polynomial();
        Polynomial res;
        res.coeff.assign(degree() + other.degree() + 1, 0);
        for (int i = 0; i <= degree(); ++i) {
            if (!coeff[i]) continue;
            for (int j = 0; j <= other.degree(); ++j) {
                if (!other.coeff[j]) continue;
                res.coeff[i + j] = FiniteField::add(res.coeff[i + j], 
                                                   FiniteField::mul(coeff[i], other.coeff[j]));
            }
        }
        res.trim();
        return res;
    }
    pair<Polynomial, Polynomial> divide(const Polynomial& divisor) const {
        if (divisor.isZero()) throw runtime_error("Division by zero");
        Polynomial quotient, remainder = *this;
        if (isZero() || degree() < divisor.degree()) 
            return {quotient, remainder};
        
        int invLead = FiniteField::inv(divisor.leading());
        quotient.coeff.assign(degree() - divisor.degree() + 1, 0);
        
        while (!remainder.isZero() && remainder.degree() >= divisor.degree()) {
            int k = remainder.degree() - divisor.degree();
            int factor = FiniteField::mul(remainder.leading(), invLead);
            quotient.coeff[k] = FiniteField::add(quotient.coeff[k], factor);
            
            for (int i = 0; i <= divisor.degree(); ++i) {
                int idx = i + k;
                remainder.coeff[idx] = FiniteField::sub(remainder.coeff[idx], 
                                                       FiniteField::mul(factor, divisor.coeff[i]));
            }
            remainder.trim();
        }
        quotient.trim();
        return {quotient, remainder};
    }
    Polynomial mod(const Polynomial& divisor) const { return divide(divisor).second; }
    Polynomial derivative() const {
        if (degree() <= 0) return Polynomial();
        Polynomial res;
        res.coeff.assign(degree(), 0);
        for (int i = 1; i <= degree(); ++i)
            res.coeff[i - 1] = FiniteField::mod(1LL * i * coeff[i]);
        res.trim();
        return res;
    }
    Polynomial makeMonic() const {
        if (isZero()) return *this;
        int inv = FiniteField::inv(leading());
        Polynomial res = *this;
        for (auto& c : res.coeff) c = FiniteField::mul(c, inv);
        return res;
    }
};

// ===================== 多项式工具函数 =====================
namespace PolyUtils {
    Polynomial gcd(Polynomial a, Polynomial b) {
        if (a.isZero()) return b.makeMonic();
        if (b.isZero()) return a.makeMonic();
        while (!b.isZero()) {
            auto [_, r] = a.divide(b);
            a = b;
            b = r;
        }
        return a.makeMonic();
    }
    
    Polynomial powMod(Polynomial base, BigUInt exp, const Polynomial& mod) {
        base = base.mod(mod);
        Polynomial res(1);
        while (!exp.zero()) {
            if (exp.odd()) res = (res * base).mod(mod);
            exp.shiftRight();
            if (!exp.zero()) base = (base * base).mod(mod);
        }
        return res;
    }
    
    Polynomial powMod(Polynomial base, uint64_t exp, const Polynomial& mod) {
        base = base.mod(mod);
        Polynomial res(1);
        while (exp) {
            if (exp & 1) res = (res * base).mod(mod);
            exp >>= 1;
            if (exp) base = (base * base).mod(mod);
        }
        return res;
    }
}

// ===================== 随机数生成器 =====================
namespace Random {
    static mt19937_64& getRNG() {
        static mt19937_64 rng(chrono::high_resolution_clock::now().time_since_epoch().count());
        return rng;
    }
    
    static int randInt(int mod) {
        return (int)(getRNG()() % (uint64_t)mod);
    }
}

// ===================== 因式分解算法 =====================
class PolynomialFactorizer {
    static Polynomial randomPoly(int maxDeg, bool allowZero = false) {
        Polynomial p;
        p = Polynomial::monomial(maxDeg);
        for (int i = 0; i <= maxDeg; ++i) {
            int coeff = Random::randInt(Config::MOD_PRIME);
            if (coeff) {
                p = p - Polynomial::monomial(i) * Polynomial(coeff);
            }
        }
        if (!allowZero && p.isZero()) return Polynomial(1);
        return p;
    }
    
public:
    static vector<pair<Polynomial, int>> squareFree(const Polynomial& f) {
        Polynomial g = f.makeMonic();
        if (g.isZero()) throw runtime_error("Input is zero");
        
        Polynomial dg = g.derivative();
        if (dg.isZero()) return {{g, 1}};
        
        Polynomial c = PolyUtils::gcd(g, dg);
        Polynomial w = g.divide(c).first;
        
        vector<pair<Polynomial, int>> result;
        int mult = 1;
        while (!w.isOne()) {
            Polynomial y = PolyUtils::gcd(w, c);
            Polynomial z = w.divide(y).first;
            if (!z.isOne()) result.push_back({z.makeMonic(), mult});
            w = y;
            c = c.divide(y).first;
            ++mult;
        }
        if (!c.isOne()) result.push_back({c.makeMonic(), mult});
        return result;
    }
    
    static vector<pair<int, Polynomial>> distinctDegree(const Polynomial& f) {
        Polynomial g = f.makeMonic();
        if (g.isZero()) throw runtime_error("Input is zero");
        
        vector<pair<int, Polynomial>> result;
        Polynomial x = Polynomial::x();
        Polynomial h = x.mod(g);
        Polynomial rem = g;
        
        for (int d = 1; !rem.isOne() && 2 * d <= rem.degree(); ++d) {
            h = PolyUtils::powMod(h, (uint64_t)Config::MOD_PRIME, rem);
            Polynomial diff = (h - x.mod(rem));
            Polynomial gd = PolyUtils::gcd(rem, diff);
            if (!gd.isOne()) {
                result.push_back({d, gd.makeMonic()});
                rem = rem.divide(gd).first;
                h = h.mod(rem);
            }
        }
        if (!rem.isOne()) result.push_back({rem.degree(), rem.makeMonic()});
        return result;
    }
    
    static vector<Polynomial> equalDegree(const Polynomial& f, int d) {
        Polynomial g = f.makeMonic();
        if (g.degree() == d) return {g};
        if (g.degree() % d != 0) throw runtime_error("Degree mismatch");
        
        BigUInt exponent(1);
        for (int i = 0; i < d; ++i) exponent.multiply(Config::MOD_PRIME);
        exponent.decrement();
        exponent.shiftRight();
        
        while (true) {
            Polynomial a = randomPoly(g.degree() - 1, false);
            Polynomial g0 = PolyUtils::gcd(g, a);
            if (!g0.isOne() && g0.degree() < g.degree()) {
                auto parts1 = equalDegree(g0, d);
                auto parts2 = equalDegree(g.divide(g0).first, d);
                parts1.insert(parts1.end(), parts2.begin(), parts2.end());
                return parts1;
            }
            
            Polynomial t = PolyUtils::powMod(a, exponent, g);
            t = t - Polynomial(1);
            Polynomial gd = PolyUtils::gcd(g, t);
            
            if (!gd.isOne() && gd.degree() < g.degree()) {
                auto parts1 = equalDegree(gd, d);
                auto parts2 = equalDegree(g.divide(gd).first, d);
                parts1.insert(parts1.end(), parts2.begin(), parts2.end());
                return parts1;
            }
        }
    }
    
    static vector<pair<Polynomial, int>> fullFactorization(const Polynomial& f) {
        vector<pair<Polynomial, int>> result;
        auto sff = squareFree(f);
        
        for (auto& [poly, mult] : sff) {
            Polynomial g = poly.makeMonic();
            if (g.degree() <= 0) continue;
            if (g.degree() == 1) {
                result.push_back({g, mult});
                continue;
            }
            
            auto ddf = distinctDegree(g);
            for (auto& [d, gd] : ddf) {
                if (gd.degree() == d) {
                    result.push_back({gd, mult});
                } else {
                    auto parts = equalDegree(gd, d);
                    for (auto& part : parts)
                        result.push_back({part.makeMonic(), mult});
                }
            }
        }
        
        sort(result.begin(), result.end(), [](auto& a, auto& b) {
            if (a.first.degree() != b.first.degree())
                return a.first.degree() < b.first.degree();
            return a.first.raw() < b.first.raw();
        });
        return result;
    }
};

// ===================== 不可约性测试 =====================
class IrreducibleTester {
public:
    static bool isIrreducible(const Polynomial& f) {
        Polynomial g = f.makeMonic();
        int n = g.degree();
        if (n <= 1) return n == 1;
        
        Polynomial x = Polynomial::x();
        Polynomial h = x.mod(g);
        
        for (int i = 1; i <= n; ++i) {
            h = PolyUtils::powMod(h, (uint64_t)Config::MOD_PRIME, g);
            if (i <= n / 2) {
                Polynomial diff = (h - x.mod(g));
                if (!PolyUtils::gcd(g, diff).isOne()) return false;
            }
        }
        return (h - x.mod(g)).isZero();
    }
    
    static Polynomial generateIrreducible(int deg) {
        while (true) {
            Polynomial cand = Polynomial::monomial(deg);
            for (int i = 0; i < deg; ++i) {
                int coeff = Random::randInt(Config::MOD_PRIME);
                if (coeff) {
                    cand = cand - Polynomial::monomial(i) * Polynomial(coeff);
                }
            }
            if (isIrreducible(cand)) return cand;
        }
    }
};

// ===================== 主函数 =====================
int main(int argc, char** argv) {
    if (argc >= 2) {
        Config::MOD_PRIME = stoi(argv[1]);
        if (!Config::isPrime(Config::MOD_PRIME) || Config::MOD_PRIME <= 11) {
            cerr << "Please provide a prime number > 11, e.g., 1000003\n";
            return 1;
        }
    }
    cout << "Finite Field: F_p, p = " << Config::MOD_PRIME << "\n";
    
    // 构造测试多项式
    auto g2a = IrreducibleTester::generateIrreducible(2);
    auto g2b = IrreducibleTester::generateIrreducible(2);
    while (g2b.raw() == g2a.raw()) 
        g2b = IrreducibleTester::generateIrreducible(2);
    auto g3 = IrreducibleTester::generateIrreducible(3);
    
    auto f = (g2a * g2b) * (g3 * g3);
    f = f.makeMonic();
    
    cout << "\nGenerated degree-10 polynomial f(x):\n  f(x) = " << f.toString() << "\n\n";
    
    auto start = chrono::high_resolution_clock::now();
    auto factors = PolynomialFactorizer::fullFactorization(f);
    auto end = chrono::high_resolution_clock::now();
    
    cout << "Factorization over F_p[x]:\n";
    for (auto& [poly, mult] : factors) {
        cout << "  (" << poly.toString() << ")";
        if (mult > 1) cout << "^" << mult;
        cout << "\n";
    }
    
    // 验证
    Polynomial product(1);
    for (auto& [poly, mult] : factors)
        for (int i = 0; i < mult; ++i) product = product * poly;
    product = product.makeMonic();
    
    cout << "\nCheck product == f: " << (product.raw() == f.raw() ? "PASS" : "FAIL") << "\n";
    cout << "Factorization time: " << chrono::duration_cast<chrono::milliseconds>(end - start).count() << " ms\n";
    
    return 0;
}