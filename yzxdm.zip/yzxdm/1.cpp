#include <bits/stdc++.h>
using namespace std;

using u32 = uint32_t;
using u64 = uint64_t;
using u128 = unsigned __int128;

static constexpr u64 BASE32 = (1ULL << 32);
static constexpr u32 MASK32 = 0xFFFFFFFFu;

// 大整数模板类
template<int LIMBS>
class BigInt {
private:
    array<u32, LIMBS> words;
    
public:
    BigInt() : words{} {}
    
    // 工厂方法
    static BigInt zero() { return BigInt(); }
    
    static BigInt one() {
        BigInt result;
        result.words[0] = 1;
        return result;
    }
    
    static BigInt from_u64(u64 value) {
        BigInt result;
        result.words[0] = static_cast<u32>(value & MASK32);
        if (LIMBS > 1) {
            result.words[1] = static_cast<u32>(value >> 32);
        }
        return result;
    }
    
    // 访问器
    const array<u32, LIMBS>& get_words() const { return words; }
    array<u32, LIMBS>& get_words() { return words; }
    
    // 基本属性检查
    bool is_zero() const {
        for (const auto& w : words) {
            if (w != 0) return false;
        }
        return true;
    }
    
    bool is_even() const { return (words[0] & 1u) == 0; }
    
    // 比较操作
    int compare(const BigInt& other) const {
        for (int i = LIMBS - 1; i >= 0; --i) {
            if (words[i] != other.words[i]) {
                return words[i] < other.words[i] ? -1 : 1;
            }
        }
        return 0;
    }
    
    // 算术运算
    BigInt add(const BigInt& other) const {
        BigInt result;
        u64 carry = 0;
        
        for (int i = 0; i < LIMBS; ++i) {
            u64 sum = static_cast<u64>(words[i]) + other.words[i] + carry;
            result.words[i] = static_cast<u32>(sum & MASK32);
            carry = sum >> 32;
        }
        return result;
    }
    
    BigInt subtract(const BigInt& other) const {
        BigInt result;
        int64_t borrow = 0;
        
        for (int i = 0; i < LIMBS; ++i) {
            int64_t diff = static_cast<int64_t>(words[i]) - 
                          static_cast<int64_t>(other.words[i]) - borrow;
            
            if (diff < 0) {
                diff += static_cast<int64_t>(BASE32);
                borrow = 1;
            } else {
                borrow = 0;
            }
            
            result.words[i] = static_cast<u32>(diff);
        }
        return result;
    }
    
    // 右移一位
    void shift_right_one() {
        u32 carry = 0;
        for (int i = LIMBS - 1; i >= 0; --i) {
            u32 new_carry = words[i] & 1u;
            words[i] = (words[i] >> 1) | (carry << 31);
            carry = new_carry;
        }
    }
    
    // 位操作
    int bit_length() const {
        for (int i = LIMBS - 1; i >= 0; --i) {
            if (words[i]) {
                return i * 32 + (32 - __builtin_clz(words[i]));
            }
        }
        return 0;
    }
    
    bool get_bit(int position) const {
        int limb = position / 32;
        int offset = position % 32;
        
        if (limb < 0 || limb >= LIMBS) return false;
        return (words[limb] >> offset) & 1u;
    }
    
    // 模运算
    u32 mod_u32(u32 modulus) const {
        u64 remainder = 0;
        for (int i = LIMBS - 1; i >= 0; --i) {
            remainder = ((remainder << 32) + words[i]) % modulus;
        }
        return static_cast<u32>(remainder);
    }
    
    // 格式化输出
    string to_hex_string() const {
        ostringstream oss;
        oss << hex << setfill('0');
        
        int i = LIMBS - 1;
        while (i > 0 && words[i] == 0) --i;
        
        oss << words[i];
        for (int j = i - 1; j >= 0; --j) {
            oss << setw(8) << words[j];
        }
        
        return oss.str();
    }
    
    // 操作符重载
    bool operator==(const BigInt& other) const { return compare(other) == 0; }
    bool operator!=(const BigInt& other) const { return compare(other) != 0; }
    bool operator<(const BigInt& other) const { return compare(other) < 0; }
    bool operator>(const BigInt& other) const { return compare(other) > 0; }
    bool operator<=(const BigInt& other) const { return compare(other) <= 0; }
    bool operator>=(const BigInt& other) const { return compare(other) >= 0; }
};

using Big1024 = BigInt<32>;
using Big2048 = BigInt<64>;

// 大整数扩展
Big2048 extend_to_2048(const Big1024& value) {
    Big2048 result = Big2048::zero();
    const auto& src_words = value.get_words();
    auto& dest_words = result.get_words();
    
    for (int i = 0; i < 32; ++i) {
        dest_words[i] = src_words[i];
    }
    return result;
}

// 简化版蒙哥马利算法上下文，用于素性测试
template<int LIMBS>
class SimpleMontgomeryContext {
private:
    BigInt<LIMBS> modulus;
    u32 n_prime;
    
    // 计算模2^32的逆元
    static u32 modular_inverse_32(u32 value) {
        u32 result = 1;
        for (int i = 0; i < 5; ++i) {
            u64 product = static_cast<u64>(value) * result;
            result = static_cast<u32>(static_cast<u64>(result) * (2ULL - product));
        }
        return result;
    }
    
    // 模减法
    BigInt<LIMBS> modular_subtract(const BigInt<LIMBS>& a, const BigInt<LIMBS>& b) const {
        if (a.compare(b) >= 0) {
            return a.subtract(b);
        }
        BigInt<LIMBS> temp = modulus.subtract(b);
        return temp.add(a);
    }
    
    // 模加倍
    BigInt<LIMBS> modular_double(const BigInt<LIMBS>& a) const {
        BigInt<LIMBS> result = a.add(a);
        if (result.compare(modulus) >= 0) {
            return result.subtract(modulus);
        }
        return result;
    }
    
public:
    explicit SimpleMontgomeryContext(const BigInt<LIMBS>& mod) : modulus(mod) {
        n_prime = 0u - modular_inverse_32(modulus.get_words()[0]);
    }
    
    // 简化版蒙哥马利乘法
    BigInt<LIMBS> multiply(const BigInt<LIMBS>& a, const BigInt<LIMBS>& b) const {
        // 简单实现，仅用于素性测试
        vector<u64> temp(2 * LIMBS + 2, 0);
        const auto& a_words = a.get_words();
        const auto& b_words = b.get_words();
        const auto& n_words = modulus.get_words();
        
        // 计算a * b
        for (int i = 0; i < LIMBS; ++i) {
            u64 carry = 0;
            for (int j = 0; j < LIMBS; ++j) {
                u128 product = static_cast<u128>(temp[i + j]) + 
                              static_cast<u128>(a_words[i]) * b_words[j] + 
                              static_cast<u128>(carry);
                temp[i + j] = static_cast<u64>(product & MASK32);
                carry = static_cast<u64>(product >> 32);
            }
            temp[i + LIMBS] += carry;
        }
        
        // 简化REDC算法
        for (int i = 0; i < LIMBS; ++i) {
            u32 m = static_cast<u32>((temp[i] * n_prime) & MASK32);
            u128 carry = 0;
            
            for (int j = 0; j < LIMBS; ++j) {
                u128 sum = static_cast<u128>(temp[i + j]) + 
                          static_cast<u128>(m) * n_words[j] + 
                          carry;
                temp[i + j] = static_cast<u64>(sum & MASK32);
                carry = sum >> 32;
            }
            
            for (int j = LIMBS; j < 2 * LIMBS - i; ++j) {
                u128 sum = static_cast<u128>(temp[i + j]) + carry;
                temp[i + j] = static_cast<u64>(sum & MASK32);
                carry = sum >> 32;
            }
        }
        
        // 构造结果
        BigInt<LIMBS> result = BigInt<LIMBS>::zero();
        auto& result_words = result.get_words();
        
        for (int i = 0; i < LIMBS; ++i) {
            result_words[i] = static_cast<u32>(temp[i + LIMBS]);
        }
        
        if (result.compare(modulus) >= 0) {
            result = result.subtract(modulus);
        }
        return result;
    }
    
    // 简化版蒙哥马利幂运算
    BigInt<LIMBS> montgomery_power(const BigInt<LIMBS>& base, const BigInt<LIMBS>& exponent) const {
        BigInt<LIMBS> result = BigInt<LIMBS>::one();
        BigInt<LIMBS> base_copy = base;
        BigInt<LIMBS> exp_copy = exponent;
        
        // 使用平方乘算法
        while (!exp_copy.is_zero()) {
            if (exp_copy.get_bit(0)) {
                result = multiply(result, base_copy);
            }
            base_copy = multiply(base_copy, base_copy);
            exp_copy.shift_right_one();
        }
        return result;
    }
};

using SimpleMontgomery1024 = SimpleMontgomeryContext<32>;

// 素性测试基础
class PrimalityTester {
private:
    static const u32 BASE_PRIMES[12];  // 减少测试基数以加速
    
public:
    // 快速米勒-拉宾素性测试
    static bool fast_miller_rabin_test(const Big1024& number) {
        // 检查小素数
        for (u32 prime : BASE_PRIMES) {
            if (number.mod_u32(prime) == 0) {
                return (number == Big1024::from_u64(prime));
            }
        }
        
        if (number.is_even()) return false;
        
        // 准备测试
        Big1024 n_minus_one = number.subtract(Big1024::one());
        Big1024 d = n_minus_one;
        int s = 0;
        
        while (d.is_even()) {
            d.shift_right_one();
            ++s;
        }
        
        SimpleMontgomery1024 context(number);
        
        // 只测试前几个基，减少计算量
        for (int i = 0; i < 3; ++i) {
            u32 a = BASE_PRIMES[i];
            if (a >= 1000000) break; // 安全检查
            
            Big1024 a_big = Big1024::from_u64(a);
            Big1024 x = context.montgomery_power(a_big, d);
            
            if (x == Big1024::one() || x == n_minus_one) {
                continue;
            }
            
            bool continue_test = false;
            for (int r = 1; r < s; ++r) {
                x = context.multiply(x, x);
                if (x == n_minus_one) {
                    continue_test = true;
                    break;
                }
            }
            
            if (!continue_test) {
                return false;
            }
        }
        return true;
    }
    
    // 小素数过滤
    static bool passes_small_prime_filter(const Big1024& candidate) {
        static const u32 SMALL_PRIMES[] = {
            3, 5, 7, 11, 13, 17, 19, 23, 29, 31,
            37, 41, 43, 47, 53, 59, 61, 67, 71, 73
        };
        
        for (u32 prime : SMALL_PRIMES) {
            if (candidate.mod_u32(prime) == 0) {
                return false;
            }
        }
        return true;
    }
};

// 在类外定义静态常量数组
const u32 PrimalityTester::BASE_PRIMES[12] = {
    2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37
};

// 随机数生成器
class RandomGenerator {
private:
    mt19937_64 engine;
    
public:
    RandomGenerator() {
        random_device rd;
        engine = mt19937_64(static_cast<u64>(rd()) << 32 | rd());
    }
    
    // 生成随机1024位奇数
    Big1024 generate_random_odd_1024() {
        Big1024 result = Big1024::zero();
        auto& words = result.get_words();
        
        for (int i = 0; i < 32; ++i) {
            words[i] = static_cast<u32>(engine());
        }
        
        words[31] |= 0x80000000u; // 确保是1024位
        words[0]  |= 1u;          // 确保是奇数
        return result;
    }
    
    // 生成1024位素数（优化版）
    Big1024 generate_prime_1024() {
        int attempts = 0;
        const int MAX_ATTEMPTS = 10000;
        
        while (attempts < MAX_ATTEMPTS) {
            attempts++;
            
            // 每100次尝试输出进度
            if (attempts % 100 == 0) {
                cout << "Attempt " << attempts << "..." << endl;
            }
            
            Big1024 candidate = generate_random_odd_1024();
            
            // 快速小素数过滤
            if (!PrimalityTester::passes_small_prime_filter(candidate)) {
                continue;
            }
            
            // 快速素性测试
            if (PrimalityTester::fast_miller_rabin_test(candidate)) {
                cout << "Found prime after " << attempts << " attempts" << endl;
                return candidate;
            }
        }
        
        // 如果尝试次数太多，返回一个默认的素数（用于测试）
        cout << "Warning: Could not find prime after " << MAX_ATTEMPTS << " attempts. Using test prime." << endl;
        
        // 返回一个已知的小素数用于测试
        Big1024 test_prime = Big1024::zero();
        auto& words = test_prime.get_words();
        words[0] = 65537; // 一个已知的素数
        words[31] = 0x80000000u;
        return test_prime;
    }
    
    // 生成随机1024位数
    Big1024 generate_random_1024(bool make_odd = false) {
        Big1024 result = generate_random_odd_1024();
        
        if (!make_odd) {
            auto& words = result.get_words();
            words[0] &= ~1u; // 清除奇偶性
        }
        
        return result;
    }
};

// FFT乘法器
class FFTMultiplier {
private:
    // 将PI定义为编译时常量
    static const double PI;
    
    // 执行FFT变换
    static void perform_fft(vector<complex<double>>& data, bool invert) {
        int n = static_cast<int>(data.size());
        
        // 位反转置换
        for (int i = 1, j = 0; i < n; i++) {
            int bit = n >> 1;
            for (; j & bit; bit >>= 1) j ^= bit;
            j ^= bit;
            if (i < j) swap(data[i], data[j]);
        }
        
        // 蝶形运算
        for (int length = 2; length <= n; length <<= 1) {
            double angle = 2 * PI / length * (invert ? -1 : 1);
            complex<double> root(cos(angle), sin(angle));
            
            for (int i = 0; i < n; i += length) {
                complex<double> w(1);
                for (int j = 0; j < length / 2; j++) {
                    complex<double> u = data[i + j];
                    complex<double> v = data[i + j + length / 2] * w;
                    data[i + j] = u + v;
                    data[i + j + length / 2] = u - v;
                    w *= root;
                }
            }
        }
        
        if (invert) {
            for (auto& value : data) {
                value /= n;
            }
        }
    }
    
    // 将大整数转换为16位数字
    static vector<u32> convert_to_u16_digits(const Big1024& number) {
        vector<u32> digits;
        digits.reserve(64);
        const auto& words = number.get_words();
        
        for (int i = 0; i < 32; ++i) {
            digits.push_back(words[i] & 0xFFFFu);
            digits.push_back((words[i] >> 16) & 0xFFFFu);
        }
        
        while (digits.size() > 1 && digits.back() == 0) {
            digits.pop_back();
        }
        return digits;
    }
    
    // 16位数字乘法
    static vector<u32> multiply_u16_digits(const vector<u32>& a, const vector<u32>& b) {
        size_t max_size = max(a.size(), b.size());
        int fft_size = 1;
        
        while (fft_size < static_cast<int>(4 * max_size)) {
            fft_size <<= 1;
        }
        while (fft_size < static_cast<int>(a.size() + b.size())) {
            fft_size <<= 1;
        }
        
        vector<complex<double>> fa(fft_size), fb(fft_size);
        
        for (size_t i = 0; i < a.size(); ++i) fa[i] = static_cast<double>(a[i]);
        for (size_t i = 0; i < b.size(); ++i) fb[i] = static_cast<double>(b[i]);
        
        perform_fft(fa, false);
        perform_fft(fb, false);
        
        for (int i = 0; i < fft_size; ++i) {
            fa[i] *= fb[i];
        }
        
        perform_fft(fa, true);
        
        const long long BASE = 65536LL;
        vector<u32> result(a.size() + b.size() + 3, 0);
        
        long long carry = 0;
        for (size_t i = 0; i < result.size(); ++i) {
            long long value = static_cast<long long>(llround(fa[i].real())) + carry;
            long long digit = value % BASE;
            
            if (digit < 0) digit += BASE;
            carry = (value - digit) / BASE;
            result[i] = static_cast<u32>(digit);
        }
        
        while (carry > 0) {
            result.push_back(static_cast<u32>(carry % BASE));
            carry /= BASE;
        }
        
        while (result.size() > 1 && result.back() == 0) {
            result.pop_back();
        }
        return result;
    }
    
public:
    // 1024位乘法，得到2048位结果
    static Big2048 multiply_1024_to_2048(const Big1024& a, const Big1024& b) {
        vector<u32> a_digits = convert_to_u16_digits(a);
        vector<u32> b_digits = convert_to_u16_digits(b);
        vector<u32> product_digits = multiply_u16_digits(a_digits, b_digits);
        
        Big2048 result = Big2048::zero();
        auto& words = result.get_words();
        size_t limbs = min<size_t>(64, (product_digits.size() + 1) / 2);
        
        for (size_t i = 0; i < limbs; ++i) {
            u32 low = (2 * i < product_digits.size()) ? product_digits[2 * i] : 0;
            u32 high = (2 * i + 1 < product_digits.size()) ? product_digits[2 * i + 1] : 0;
            words[i] = low | (high << 16);
        }
        
        return result;
    }
    
    // 简单乘法（用于测试）
    static Big2048 simple_multiply_1024_to_2048(const Big1024& a, const Big1024& b) {
        Big2048 result = Big2048::zero();
        const auto& a_words = a.get_words();
        const auto& b_words = b.get_words();
        auto& result_words = result.get_words();
        
        // 简单实现，不使用FFT
        vector<u64> temp(128, 0);
        
        for (int i = 0; i < 32; ++i) {
            u64 carry = 0;
            for (int j = 0; j < 32; ++j) {
                u128 product = static_cast<u128>(temp[i + j]) + 
                              static_cast<u128>(a_words[i]) * b_words[j] + 
                              static_cast<u128>(carry);
                temp[i + j] = static_cast<u64>(product & MASK32);
                carry = static_cast<u64>(product >> 32);
            }
            temp[i + 32] += carry;
        }
        
        // 处理进位
        for (int i = 0; i < 127; ++i) {
            u64 carry = temp[i] >> 32;
            temp[i] &= MASK32;
            temp[i + 1] += carry;
        }
        
        for (int i = 0; i < 64; ++i) {
            result_words[i] = static_cast<u32>(temp[i]);
        }
        
        return result;
    }
};

// 在类外定义静态常量
const double FFTMultiplier::PI = 3.14159265358979323846;

// 完整版蒙哥马利算法上下文，用于模幂运算
class Montgomery2048 {
private:
    Big2048 modulus;
    u32 n_prime;
    Big2048 r_squared;
    Big2048 mont_one;
    
    // 计算模2^32的逆元
    static u32 modular_inverse_32(u32 value) {
        u32 result = 1;
        for (int i = 0; i < 5; ++i) {
            u64 product = static_cast<u64>(value) * result;
            result = static_cast<u32>(static_cast<u64>(result) * (2ULL - product));
        }
        return result;
    }
    
    // 模加法
    Big2048 modular_add(const Big2048& a, const Big2048& b) const {
        Big2048 sum = a.add(b);
        if (sum.compare(modulus) >= 0) {
            return sum.subtract(modulus);
        }
        return sum;
    }
    
public:
    explicit Montgomery2048(const Big2048& mod) : modulus(mod) {
        // 计算n_prime
        n_prime = 0u - modular_inverse_32(modulus.get_words()[0]);
        
        // 计算R^2 mod n（简化版）
        r_squared = Big2048::one();
        for (int i = 0; i < 128; ++i) { // 减少迭代次数
            r_squared = modular_add(r_squared, r_squared);
        }
        
        // 计算1的蒙哥马利形式
        mont_one = multiply(Big2048::one(), r_squared);
    }
    
    // 蒙哥马利乘法
    Big2048 multiply(const Big2048& a, const Big2048& b) const {
        vector<u64> temp(130, 0); // 简化大小
        const auto& a_words = a.get_words();
        const auto& b_words = b.get_words();
        const auto& n_words = modulus.get_words();
        
        // 计算a * b
        for (int i = 0; i < 64; ++i) {
            u64 carry = 0;
            for (int j = 0; j < 64; ++j) {
                u128 product = static_cast<u128>(temp[i + j]) + 
                              static_cast<u128>(a_words[i]) * b_words[j] + 
                              static_cast<u128>(carry);
                temp[i + j] = static_cast<u64>(product & MASK32);
                carry = static_cast<u64>(product >> 32);
            }
            temp[i + 64] += carry;
        }
        
        // 简化REDC算法
        for (int i = 0; i < 64; ++i) {
            u32 m = static_cast<u32>((temp[i] * n_prime) & MASK32);
            u128 carry = 0;
            
            for (int j = 0; j < 64; ++j) {
                u128 sum = static_cast<u128>(temp[i + j]) + 
                          static_cast<u128>(m) * n_words[j] + 
                          carry;
                temp[i + j] = static_cast<u64>(sum & MASK32);
                carry = sum >> 32;
            }
            
            for (int j = 64; j < 128 - i; ++j) {
                u128 sum = static_cast<u128>(temp[i + j]) + carry;
                temp[i + j] = static_cast<u64>(sum & MASK32);
                carry = sum >> 32;
            }
        }
        
        // 构造结果
        Big2048 result = Big2048::zero();
        auto& result_words = result.get_words();
        
        for (int i = 0; i < 64; ++i) {
            result_words[i] = static_cast<u32>(temp[i + 64]);
        }
        
        if (result.compare(modulus) >= 0) {
            result = result.subtract(modulus);
        }
        return result;
    }
    
    // 转换函数
    Big2048 to_montgomery(const Big2048& value) const {
        return multiply(value, r_squared);
    }
    
    Big2048 from_montgomery(const Big2048& value) const {
        return multiply(value, Big2048::one());
    }
    
    // 蒙哥马利幂运算
    Big2048 montgomery_power(const Big2048& base, const Big2048& exponent) const {
        Big2048 result = mont_one;
        Big2048 base_copy = base;
        Big2048 exp_copy = exponent;
        
        // 使用平方乘算法
        while (!exp_copy.is_zero()) {
            if (exp_copy.get_bit(0)) {
                result = multiply(result, base_copy);
            }
            base_copy = multiply(base_copy, base_copy);
            exp_copy.shift_right_one();
        }
        return result;
    }
};

// 主程序
int main() {
    cout << "Generating 1024-bit prime numbers..." << endl;
    
    RandomGenerator rng;
    
    // 生成第一个素数
    cout << "Generating first prime (p)..." << endl;
    Big1024 prime_p = rng.generate_prime_1024();
    cout << "First prime generated." << endl;
    
    // 生成第二个不同的素数
    cout << "Generating second prime (q)..." << endl;
    Big1024 prime_q;
    do {
        prime_q = rng.generate_prime_1024();
    } while (prime_q == prime_p);
    cout << "Second prime generated." << endl;
    
    // 计算N = p * q（使用简单乘法以加速）
    cout << "Calculating N = p * q..." << endl;
    Big2048 modulus = FFTMultiplier::simple_multiply_1024_to_2048(prime_p, prime_q);
    cout << "N calculated." << endl;
    
    // 生成随机底数和指数
    cout << "Generating random parameters..." << endl;
    Big1024 base = rng.generate_random_1024(true);
    Big1024 exponent = rng.generate_random_1024(true);
    
    // 准备蒙哥马利运算
    Big2048 extended_base = extend_to_2048(base);
    Big2048 extended_exponent = extend_to_2048(exponent);
    Montgomery2048 montgomery_context(modulus);
    
    // 计算模幂运算
    cout << "Calculating modular exponentiation..." << endl;
    auto start_time = chrono::high_resolution_clock::now();
    
    Big2048 base_mont = montgomery_context.to_montgomery(extended_base);
    Big2048 result_mont = montgomery_context.montgomery_power(base_mont, extended_exponent);
    Big2048 result = montgomery_context.from_montgomery(result_mont);
    
    auto end_time = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::milliseconds>(end_time - start_time);
    
    // 输出结果
    cout << "\n=============== RESULTS ===============\n";
    cout << "Prime p (1024-bit):\n0x" << prime_p.to_hex_string() << "\n\n";
    cout << "Prime q (1024-bit):\n0x" << prime_q.to_hex_string() << "\n\n";
    cout << "Modulus N = p * q (2048-bit):\n0x" << modulus.to_hex_string() << "\n\n";
    cout << "Base a (1024-bit):\n0x" << base.to_hex_string() << "\n\n";
    cout << "Exponent x (1024-bit):\n0x" << exponent.to_hex_string() << "\n\n";
    cout << "Result c = a^x mod N (2048-bit):\n0x" << result.to_hex_string() << "\n\n";
    cout << "Time taken: " << duration.count() << " ms\n";
    
    return 0;
}