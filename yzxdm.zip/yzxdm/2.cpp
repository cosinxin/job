#include <cstdint>
#include <cstdio>
#include <chrono>

using u32 = uint32_t;
using u64 = uint64_t;

constexpr int WORDS = 32;           // 1024-bit = 32 * 32-bit words
constexpr u64 BASE = 1ULL << 32;    // Radix 2^32

// --------------------- Random Number Generator ---------------------
class XorShift64 {
    u64 state;
public:
    explicit XorShift64(u64 seed) : state(seed ? seed : 0xDEADBEEFCAFEBABE) {}
    
    u64 next() {
        u64 x = state;
        x ^= x >> 12;
        x ^= x << 25;
        x ^= x >> 27;
        state = x;
        return x * 0x2545F4914F6CDD1DULL;
    }
    
    u32 next_u32() { return static_cast<u32>(next() >> 32); }
};

static XorShift64& get_rng() {
    static u64 seed = []() -> u64 {
        auto t = std::chrono::high_resolution_clock::now().time_since_epoch().count();
        return t ^ reinterpret_cast<u64>(&t) ^ 0x9E3779B97F4A7C15ULL;
    }();
    static XorShift64 rng(seed);
    return rng;
}

static void random_bigint(u32 a[WORDS]) {
    auto& rng = get_rng();
    for (int i = 0; i < WORDS; ++i) a[i] = rng.next_u32();
    a[WORDS-1] |= 0x80000000u;  // Ensure highest bit is set for 1024-bit length
}

// --------------------- Big Integer Utilities ---------------------
static bool is_all_zero(const u32 a[WORDS]) {
    for (int i = 0; i < WORDS; ++i) if (a[i]) return false;
    return true;
}

static int actual_length(const u32* a, int max_len) {
    for (int i = max_len-1; i >= 0; --i) 
        if (a[i]) return i+1;
    return 1;
}

static int compare_bigints(const u32* a, int na, const u32* b, int nb) {
    na = actual_length(a, na);
    nb = actual_length(b, nb);
    if (na != nb) return (na > nb) ? 1 : -1;
    for (int i = na-1; i >= 0; --i) {
        if (a[i] != b[i]) return (a[i] > b[i]) ? 1 : -1;
    }
    return 0;
}

// --------------------- Big Integer Arithmetic ---------------------
static u32 add_words(u32* dest, const u32* src, int n) {
    u64 carry = 0;
    for (int i = 0; i < n; ++i) {
        u64 sum = (u64)dest[i] + (u64)src[i] + carry;
        dest[i] = (u32)sum;
        carry = sum >> 32;
    }
    return (u32)carry;
}

static u32 sub_words(u32* dest, const u32* src, int n) {
    u64 borrow = 0;
    for (int i = 0; i < n; ++i) {
        u64 diff = (u64)dest[i] - (u64)src[i] - borrow;
        dest[i] = (u32)diff;
        borrow = (diff >> 32) & 1;
    }
    return (u32)borrow;
}

// --------------------- Multiplication/Division Helpers ---------------------
static void multiply_by_word(const u32* src, int n, u32 multiplier, u32* dest) {
    u64 carry = 0;
    for (int i = 0; i < n; ++i) {
        u64 prod = (u64)src[i] * multiplier + carry;
        dest[i] = (u32)prod;
        carry = prod >> 32;
    }
    dest[n] = (u32)carry;
}

static u32 divide_by_word(u32* num, int n, u32 divisor) {
    u64 remainder = 0;
    for (int i = n-1; i >= 0; --i) {
        u64 cur = (remainder << 32) | num[i];
        num[i] = (u32)(cur / divisor);
        remainder = cur % divisor;
    }
    return (u32)remainder;
}

// --------------------- Modular Arithmetic Core ---------------------
static bool subtract_multiple(u32* u, int offset, const u32* v, int m, u32 q) {
    u64 borrow = 0, carry = 0;
    for (int i = 0; i < m; ++i) {
        u64 product = (u64)q * v[i] + carry;
        carry = product >> 32;
        u64 subtrahend = (product & 0xFFFFFFFFULL) + borrow;
        u64 minuend = u[offset + i];
        if (minuend < subtrahend) {
            u[offset + i] = (u32)(minuend + BASE - subtrahend);
            borrow = 1;
        } else {
            u[offset + i] = (u32)(minuend - subtrahend);
            borrow = 0;
        }
    }
    u64 total = carry + borrow;
    u64 top = u[offset + m];
    if (top < total) {
        u[offset + m] = (u32)(top + BASE - total);
        return true;
    }
    u[offset + m] = (u32)(top - total);
    return false;
}

static void compute_modulus(const u32 dividend[WORDS], const u32 divisor[WORDS], u32 remainder[WORDS]) {
    if (is_all_zero(divisor)) {
        for (int i = 0; i < WORDS; ++i) remainder[i] = 0;
        return;
    }
    
    int len_a = actual_length(dividend, WORDS);
    int len_b = actual_length(divisor, WORDS);
    
    if (compare_bigints(dividend, len_a, divisor, len_b) < 0) {
        for (int i = 0; i < WORDS; ++i) remainder[i] = dividend[i];
        return;
    }
    
    // Special case: single-word divisor
    if (len_b == 1) {
        u64 rem = 0;
        for (int i = len_a-1; i >= 0; --i) {
            u64 cur = (rem << 32) | dividend[i];
            rem = cur % divisor[0];
        }
        for (int i = 0; i < WORDS; ++i) remainder[i] = 0;
        remainder[0] = (u32)rem;
        return;
    }
    
    // Normalization
    u32 norm = (u32)(BASE / ((u64)divisor[len_b-1] + 1));
    u32 v_norm[WORDS+1] = {0};
    u32 u_norm[WORDS+2] = {0};
    
    multiply_by_word(divisor, len_b, norm, v_norm);
    multiply_by_word(dividend, len_a, norm, u_norm);
    
    // Long division
    for (int j = len_a - len_b; j >= 0; --j) {
        u64 high = ((u64)u_norm[j+len_b] << 32) | u_norm[j+len_b-1];
        u64 q_est = high / v_norm[len_b-1];
        u64 r_est = high % v_norm[len_b-1];
        
        if (q_est >= BASE) q_est = BASE - 1;
        
        while (q_est * v_norm[len_b-2] > r_est * BASE + u_norm[j+len_b-2]) {
            --q_est;
            r_est += v_norm[len_b-1];
            if (r_est >= BASE) break;
        }
        
        if (subtract_multiple(u_norm, j, v_norm, len_b, (u32)q_est)) {
            add_words(&u_norm[j], v_norm, len_b);
        }
    }
    
    // Denormalization
    for (int i = 0; i < WORDS; ++i) remainder[i] = 0;
    for (int i = 0; i < len_b; ++i) remainder[i] = u_norm[i];
    divide_by_word(remainder, len_b, norm);
}

// --------------------- Euclidean Algorithm ---------------------
static void euclidean_gcd(u32 a[WORDS], u32 b[WORDS], u32 result[WORDS]) {
    u32 temp[WORDS];
    while (!is_all_zero(b)) {
        compute_modulus(a, b, temp);
        for (int i = 0; i < WORDS; ++i) a[i] = b[i];
        for (int i = 0; i < WORDS; ++i) b[i] = temp[i];
    }
    for (int i = 0; i < WORDS; ++i) result[i] = a[i];
}

// --------------------- Binary GCD Algorithm ---------------------
static bool is_even(const u32 a[WORDS]) { return (a[0] & 1) == 0; }

static void right_shift(u32 a[WORDS]) {
    u32 carry = 0;
    for (int i = WORDS-1; i >= 0; --i) {
        u32 new_carry = a[i] & 1;
        a[i] = (a[i] >> 1) | (carry << 31);
        carry = new_carry;
    }
}

static void left_shift_bits(u32 a[WORDS], int bits) {
    if (bits <= 0) return;
    int words_shift = bits / 32;
    int bit_shift = bits % 32;
    
    u32 temp[WORDS] = {0};
    for (int i = WORDS-1; i >= 0; --i) {
        int src = i - words_shift;
        temp[i] = (src >= 0) ? a[src] : 0;
    }
    
    if (bit_shift == 0) {
        for (int i = 0; i < WORDS; ++i) a[i] = temp[i];
        return;
    }
    
    u32 carry = 0;
    for (int i = 0; i < WORDS; ++i) {
        u64 val = ((u64)temp[i] << bit_shift) | carry;
        a[i] = (u32)val;
        carry = (u32)(val >> 32);
    }
}

static void subtract_bigints(u32 a[WORDS], const u32 b[WORDS]) {
    u64 borrow = 0;
    for (int i = 0; i < WORDS; ++i) {
        u64 diff = (u64)a[i] - (u64)b[i] - borrow;
        a[i] = (u32)diff;
        borrow = (diff >> 32) & 1;
    }
}

static int compare_full(const u32 a[WORDS], const u32 b[WORDS]) {
    for (int i = WORDS-1; i >= 0; --i) {
        if (a[i] != b[i]) return (a[i] > b[i]) ? 1 : -1;
    }
    return 0;
}

static void binary_gcd(u32 x[WORDS], u32 y[WORDS], u32 result[WORDS]) {
    if (is_all_zero(x)) {
        for (int i = 0; i < WORDS; ++i) result[i] = y[i];
        return;
    }
    if (is_all_zero(y)) {
        for (int i = 0; i < WORDS; ++i) result[i] = x[i];
        return;
    }
    
    int shift = 0;
    while (is_even(x) && is_even(y)) {
        right_shift(x);
        right_shift(y);
        ++shift;
    }
    while (is_even(x)) right_shift(x);
    
    while (!is_all_zero(y)) {
        while (is_even(y)) right_shift(y);
        if (compare_full(x, y) > 0) {
            u32 temp[WORDS];
            for (int i = 0; i < WORDS; ++i) temp[i] = x[i];
            for (int i = 0; i < WORDS; ++i) x[i] = y[i];
            for (int i = 0; i < WORDS; ++i) y[i] = temp[i];
        }
        subtract_bigints(y, x);
    }
    
    left_shift_bits(x, shift);
    for (int i = 0; i < WORDS; ++i) result[i] = x[i];
}

// --------------------- Output Functions ---------------------
static void print_hexadecimal(const char* label, const u32 num[WORDS]) {
    std::printf("%s = 0x", label);
    for (int i = WORDS-1; i >= 0; --i) std::printf("%08X", num[i]);
    std::printf("\n");
}

static void print_decimal(const char* label, const u32 num[WORDS]) {
    if (is_all_zero(num)) {
        std::printf("%s = 0\n", label);
        return;
    }
    
    u32 temp[WORDS];
    for (int i = 0; i < WORDS; ++i) temp[i] = num[i];
    
    u32 chunks[120] = {0};
    int count = 0;
    int len = actual_length(temp, WORDS);
    
    while (len > 1 || temp[0] != 0) {
        u32 rem = divide_by_word(temp, len, 1000000000u);
        chunks[count++] = rem;
        len = actual_length(temp, len);
        if (len == 1 && temp[0] == 0) break;
    }
    
    std::printf("%s = %u", label, chunks[count-1]);
    for (int i = count-2; i >= 0; --i) std::printf("%09u", chunks[i]);
    std::printf("\n");
}

// --------------------- Verification Functions ---------------------
static bool arrays_equal(const u32 a[WORDS], const u32 b[WORDS]) {
    for (int i = 0; i < WORDS; ++i) if (a[i] != b[i]) return false;
    return true;
}

static void verify_gcd(const u32 a[WORDS], const u32 b[WORDS], const u32 g[WORDS]) {
    u32 rem1[WORDS], rem2[WORDS];
    compute_modulus(a, g, rem1);
    compute_modulus(b, g, rem2);
    bool divides = is_all_zero(rem1) && is_all_zero(rem2);
    
    u32 a_copy[WORDS], b_copy[WORDS], g2[WORDS];
    for (int i = 0; i < WORDS; ++i) a_copy[i] = a[i];
    for (int i = 0; i < WORDS; ++i) b_copy[i] = b[i];
    binary_gcd(a_copy, b_copy, g2);
    bool matches = arrays_equal(g, g2);
    
    std::printf("Verification 1: g divides both a and b -> %s\n", divides ? "PASS" : "FAIL");
    std::printf("Verification 2: matches binary algorithm -> %s\n", matches ? "PASS" : "FAIL");
}

// --------------------- Main Function ---------------------
int main() {
    u32 num1[WORDS], num2[WORDS];
    random_bigint(num1);
    random_bigint(num2);
    
    print_hexadecimal("First number", num1);
    print_hexadecimal("Second number", num2);
    
    u32 copy1[WORDS], copy2[WORDS], gcd[WORDS];
    for (int i = 0; i < WORDS; ++i) copy1[i] = num1[i];
    for (int i = 0; i < WORDS; ++i) copy2[i] = num2[i];
    
    auto start = std::chrono::high_resolution_clock::now();
    euclidean_gcd(copy1, copy2, gcd);
    auto end = std::chrono::high_resolution_clock::now();
    
    print_decimal("GCD", gcd);
    
    double elapsed = std::chrono::duration<double, std::milli>(end - start).count();
    std::printf("Computation time: %.3f ms\n", elapsed);
    
    verify_gcd(num1, num2, gcd);
    
    return 0;
}